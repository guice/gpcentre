<?

// A quick add of this's project's lib path
set_include_path( dirname(dirname(__FILE__)).'/lib:.');

require_once('Zend/Loader/Autoloader.php');
$al = Zend_Loader_Autoloader::getInstance();
$al->registerNamespace('RS');

// Random dummy data to load into the class
$data = array(
	'Kitchen Temperature' => array('type' => 'thermostat',
								    'max' => '80', 
									'min' => '70',
									'temperature' => rand(50, 100)),
	'Basement Temperature' => array('type' => 'thermostat',
								   'max' => '35',
									'min' => '25', 
									'temperature' =>  rand(20, 50) ),
	'Front Door' => array('type' => 'door',
								   'state' => (rand(1,5) % 2) ), // A cheet; door open/closed is stored as boolean
	'Back Door' => array('type' => 'door',
								   'state' => (rand(1,5) % 2) ), // A cheet; door open/closed is stored as boolean
	'Basement' => array('type' => 'glass',
								   'frequency' => rand(500, 1500)),
	'Main Floor' => array('type' => 'glass',
								   'frequency' => rand(500, 1500)),
	'Upstairs' => array('type' => 'glass',
								   'frequency' => rand(500, 1500)),
	'Bedroom 1' => array('type' => 'smoke',
								   'visibility' => rand(32, 95) ),
	'Bedroom 2' => array('type' => 'smoke',
								   'visibility' => rand(32, 95) ),
	'Hallway' => array('type' => 'smoke',
								   'visibility' => rand(32, 95) ),	
);

// Loading of the data, of course.
$sensors = RS\Sensors::setSensors( $data );

echo '<?xml version="1.0" encoding="UTF-8"?>'; 

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
	"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
	<title>index</title>
	
</head>
<style type="text/css">
	table {
		width: 500px;
	}
	table th {
		background: #ccc;
	}
	
	table tr {
		background: #cfc;
	}
	
	table tr.alarm {
		background: #fcc;
	}
</style>

<body>

<table border="0"> 
	<tr>
		<th>Name</th>
		<th>Type</th>
		<th>State</th>
		<th>Alarmed</th>
	</tr>
<? foreach ( $sensors as $sensor ): ?>
	<tr<?= ($sensor->hasAlarmed() ? ' class="alarm"' : null) ?>>
		<td><?= $sensor->getName() ?></td>
		<td><?= $sensor->getType() ?></td>
		<td><?= $sensor->getState() ?></td>
		<td><?= ($sensor->hasAlarmed() ? 'ALARM' : null) ?></td>
	</tr>
<? endforeach; ?>
</table>

</body>
</html>
