<?

namespace RS;

/**
 * Base sensor class, cannot be instantiated directly.
 */
abstract class Sensor {
	
	static private $_knownSensors;
	
	protected $state;
	protected $type;
	
	abstract public function hasAlarmed();
	
	/**
	 * Uses self-internal "cache" of known sensors. Creates a new object for any new
	 *   sensor.
	 * (I originally had this being a base class, but moved stuff to Sensors, and decided 
	 *    to just keep this code here.)
	 * @throws \Exception
	 * @return RS\Sensor
	 */
	static public function getSensor( $type, $name, $options = array() ) {
		
		if ( empty( self::$_knownSensors[$type][$name] ) ) {
			$qualifiedName = 'RS\Sensor\\' . ucfirst($type);
			if ( ! class_exists( $qualifiedName ) ) {
				throw new \Exception('Unknown sensor type');
			}
			
			self::$_knownSensors[$type][$name] = new $qualifiedName($name, $options);
		}
		
		return self::$_knownSensors[$type][$name];
	}
	
	public function __construct( $name, $options = array()  ) {
		$this->name = $name;
		
		// Simple method of calling 'set' methods for any key name with its
		//   supplied value.
		foreach ( $options as $name => $val ) {
			$method = 'set' . $name;
			if ( method_exists($this, $method ) ) {
				$this->$method($val);
			}
		}
	}
	
	/**
	 * @return mixed
	 */
	public function getState() {
		return $this->state;
	}
	
	public function setState( $state ) {
		$this->state = $state;
	}
	
	public function setType( $type ) {
		$this->type = ucfirst($type);
	}
	
	/**
	 * @return string
	 */
	public function getType() {
		return $this->type;
	}
	
	/**
	 * @return string
	 */
	public function getName() {
		return $this->name;
	}
}