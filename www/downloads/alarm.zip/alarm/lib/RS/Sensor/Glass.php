<?

namespace RS\Sensor;
use RS\Sensor;

/**
 * Listens for frequencies greater than a certain pitch in hz.
 */
class Glass extends Sensor {
	
	const BREAK_FREQUENCY = '1200';
	
	/**
	 * @return boolean
	 */
	public function hasAlarmed() {
		return $this->state > self::BREAK_FREQUENCY;
	}
	
	/**
	 * @return string
	 */
	public function getState() {
		return $this->state . 'hz';
	}
	
	// Sets the state, using the parent method. Alias for ease of use.
	public function setFrequency( $frequency ) {
		parent::setState($frequency);
	}
}