<?

namespace RS\Sensor;
use RS\Sensor;

/**
 * Checks for visibility < 75%, indicating excessive smoke
 */
class Smoke extends Sensor {
	
	const ACCEPTED_VISIBILITY = '75'; // in percentage
	
	/**
	 * @return boolean
	 */
	public function hasAlarmed() {
		return $this->state < self::ACCEPTED_VISIBILITY;
	}
	
	/**
	 * @return string
	 */
	public function getState() {
		return $this->state . '% Visibility';
	}
	
	// Sets the state, using the parent method. Alias for ease of use.
	public function setVisibility( $visibility ) {
		parent::setState($visibility);
	}	
}