<?

namespace RS\Sensor;
use RS\Sensor;

/**
 * Checks if the door is currently open.
 */
class Door extends Sensor {
	
	// Handling open/close states as booleans.
	const STATE_CLOSE = false;
	const STATE_OPEN = true;
	
	/**
	 * @return boolean
	 */
	public function hasAlarmed() {
		return $this->state == self::STATE_OPEN;
	}
	
	/**
	 * @return string
	 */
	public function getState() {
		return ( $this->state ? 'Opened' : 'Closed' );
	}
	
	// Sets the state, using the parent method. Aliases for ease of use.
	public function open() {
		parent::setState(self::STATE_OPEN);
	}
	
	public function close() {
		parent::setState(self::STATE_CLOSE);
	}
	
}