<?

namespace RS\Sensor;
use RS\Sensor;

/**
 * Checks to insure temperature remains within a set min/max zone.
 */
class Thermostat extends Sensor {
	
	protected $max;
	protected $min;
	
	// Setters for min/max temps - handles both cold and heat.
	public function setMin( $min ) {
		$this->min = $min;
	}
		
	public function setMax( $max ) {
		$this->max = $max;
	}
	
	// Overloaded / implemented methods.
	/**
	 * @return boolean
	 */
	public function hasAlarmed() {
		return ( $this->state > $this->max || $this->state < $this->min);
	}
	
	/**
	 * @return string
	 */
	public function getState() {
		return $this->state . ' Degrees';
	}
	
	// Sets the state, using the parent method. Alias for ease of use.
	public function setTemperature( $temp ) {
		parent::setState($temp);
	}
}