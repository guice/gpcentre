<?

namespace RS;

/**
 * An list class to store and manage a list of sensors.
 */
class Sensors implements \SeekableIterator, \Countable {
	
	private $_sensors = array();
	
	// Used by implemented interface methods
	protected $idx;
	protected $_pointer;

    /**
     * Adds a sensor to the list 
     */
	public function addSensor( Sensor $sensor ) {
		
		$this->_sensors[] = $sensor;
		$this->_count = count($this->_sensors);
	}
	
	/**
	 * Accepts an array of sensor information and generates a list object 
	 *   of all sensors.
	 * @return RS\Sensors
	 */
	static public function setSensors( $sensors = array() ) {
		
		$self = new self();
		
		foreach ( $sensors as $name => $options ) {
			$self->addSensor( Sensor::getSensor( $options['type'], $name, $options ) );
		}
		
		return $self;
	}
	
	/**
	 * Below are the required functions from the implemented interfaces above.
	 *  - probably don't need Countable, but eh.
	 */
	
	public function next() {
		++$this->_pointer;
	}
	
	public function current() {
		if ( $this->valid() === false ) {
			return null;
		}
		
		return $this->_sensors[$this->_pointer];
	}
	
	public function key() {
		return $this->_pointer;
	}
	
	public function seek( $idx ) {
		if ($idx < 0 || $idx >= $this->count() ) {
		    throw new \Exception("Illegal index $idx");
		}
		$this->_pointer = $idx;
		return $this;
	}
	
	public function count() {
		return $this->_count;
	}
	
	public function rewind() {
		$this->_pointer = 0;
        return $this;
	}
	
	public function valid() {
		return $this->_pointer >= 0 && $this->_pointer < $this->_count;
	}
}